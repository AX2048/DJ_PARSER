<?php 

phpinfo();

?>